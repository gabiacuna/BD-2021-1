Gabriela Acuña rol: 201973504-7

Este programa se desarrollo en Arch-Linux (manjaro) y se utilizo LAMP.

Como DBMS se utilizo DBeaver.

Se mantuvieron todas las asumpciones realizadas en el informe.
* La busqueda de tags es sin el #.
* Para encontrar un usmito se debe buscar su contenido completo litreralemente.
* Reusmear no crea un nuevo usmito! solo lo muestra en el perfil del usuario que reusmeo y en el feed de las personas que lo sigan.