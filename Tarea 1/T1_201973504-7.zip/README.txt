Gabriela Acuña, rol: 201973504-7

Consideraciones:

Se considera que los nombres de las comunas y regions no se repiten :)

Se considero que los datos ingresados en los archivos iniciales estan correctos, y  no poseen ninguna region para la cual su positividad sea mayor a 15%

Los formatos de entrada via consola deben seguir lo solicitado por el progrema. ej, ingresar los datos separados por ', '.

Ejecución:

    Orden:
1.- casosPorRegion.py
2.- casosPorComuna.py
3.- main.py

~ se pueden correr con py nombre_archivo o f5 desde vs.
