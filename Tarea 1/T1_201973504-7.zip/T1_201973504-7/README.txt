Gabriela Acuña, rol: 201973504-7

Consideraciones:

Se considera que los nombres de las comunas y regions no se repiten :)

Se considero que los datos ingresados en los archivos iniciales estan correctos, y  no poseen ninguna region para la cual su positividad sea mayor a 15%

Ejecución:

1° correr casosPorRegion,  luego casosPorComuna, al final main.
